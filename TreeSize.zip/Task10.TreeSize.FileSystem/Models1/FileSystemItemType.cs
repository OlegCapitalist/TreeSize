﻿namespace Task10.TreeSize.FileSystem.Models1;

public enum FileSystemItemType
{
    Folder,
    File
}