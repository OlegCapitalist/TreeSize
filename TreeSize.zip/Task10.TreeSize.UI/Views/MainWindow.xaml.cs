﻿using System;
using System.Windows;
using Task10.TreeSize.FileSystem.Services;
using Prism.Unity;

namespace Task10.TreeSize.UI.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
   public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}