﻿namespace Task10.TreeSize.FileSystem.Models;

public enum FileSystemItemType
{
    Folder,
    File
}